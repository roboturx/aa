QTDark
======



(Very) Old screenshots:
![Screenshot](/screenshots/palette.png "Color Palette")
![Screenshot](/screenshots/screenshot_1.png "Screenshot 1")
