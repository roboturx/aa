QList<QAction*> allActions;
allActions = rootWidget->findChildren<QAction*>(0);
