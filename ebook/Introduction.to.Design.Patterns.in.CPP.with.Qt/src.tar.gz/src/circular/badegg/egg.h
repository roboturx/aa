#ifndef EGG_H
#define EGG_H
//class Chicken;
//start
#include "chicken.h"
class Egg {
 public:
    Chicken* getParent(); 
};
//end
#endif        //  #ifndef EGG_H
