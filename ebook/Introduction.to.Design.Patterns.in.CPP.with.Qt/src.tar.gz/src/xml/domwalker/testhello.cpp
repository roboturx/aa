#include <cstdio>
int main(int argc, char** argv) {
    printf ("Hello World");
    for (int i=0; i < 10; ++i) {
        j = i && i;
    }
    return 0;
}
