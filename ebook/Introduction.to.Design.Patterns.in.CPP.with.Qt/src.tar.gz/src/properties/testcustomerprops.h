#ifndef TESTCUSTOMERPROPS_H
#define TESTCUSTOMERPROPS_H

#include <QtTest>
class TestCustomerProps : public QObject {
    Q_OBJECT
private slots:
    void test();
};

#endif        //  #ifndef TESTCUSTOMERPROPS_H
