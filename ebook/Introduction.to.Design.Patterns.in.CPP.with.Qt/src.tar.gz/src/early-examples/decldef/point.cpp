
extern int step;       /* An object (variable) declaration. */
class Map;             /* A (forward) class declaration. */
int max(int a, int b); /* A global (non member) function declaration. */

