#include <iostream>
using namespace std;
int main() {
    cout << "\n\tTitle 1\t\t\"Cat Clothing\"\n\tTitle 2\t\t\"Dog Dancing\"\n" << endl;
    return 0;
}
/*out
        Title 1         "Cat Clothing"
        Title 2         "Dog Dancing"
*/
