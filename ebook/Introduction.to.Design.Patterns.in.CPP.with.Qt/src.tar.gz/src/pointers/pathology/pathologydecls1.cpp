#include <iostream>
using namespace std;
//start

int main() {
    int a, b, c;  /* As expected, this line creates three ints.*/
    int* d, e, f; /* This line creates one pointer to an int and two ints. (!) */
    int *g, *h;   /* This line creates two pointers to int. */
    int* i, * j;  /* This line also creates two pointers to int.
    */

    return 0;
}

