These classes provide a shortcut editor for main window applications.
Known bugs: Selection of filtered tables seems to give incorrect index
results.

