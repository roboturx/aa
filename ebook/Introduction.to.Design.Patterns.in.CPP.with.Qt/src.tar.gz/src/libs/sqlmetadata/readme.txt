This library has been tested on linux with MySQL and SQLite.
It has also been tested on Windows with SQLite.
It requires Qt 4.6 or later to build/run.

the DbConnectionForm class is general-purpose enough that you may
want to use it in a program that does not use metadata at all.

The other classes are for writing a media player application.

