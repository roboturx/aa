These files contain solutions to exercises in Chapter 16.

