#ifndef TESTCUSTOMERLIST_H
#define TESTCUSTOMERLIST_H

#include <QtTest/QtTest>

class TestCustomerList : public QObject {
    Q_OBJECT
private slots:
    void test();

};

#endif

