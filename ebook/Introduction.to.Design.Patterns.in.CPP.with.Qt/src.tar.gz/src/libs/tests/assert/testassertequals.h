#ifndef TESTASSERTEQUALS_H
#define TESTASSERTEQUALS_H
//start

#include <QtTest>

class TestAssertEquals:public QObject {
    Q_OBJECT
private slots:
    void test ();
};

//end
#endif

