#ifndef CPPHIGHLIGHTER_H
#define CPPHIGHLIGHTER_H
#include "chighlighter.h"


class CPPHighlighter : public CHighlighter
{
public:
    CPPHighlighter(QTextDocument *parent = nullptr);
};

#endif // CPPHIGHLIGHTER_H
