#include "benimseriport.h"
#include "anapencere.h"

BenimSeriPort::BenimSeriPort()
{

}
void BenimSeriPort::writeData(){

}
void BenimSeriPort::readData(char* data){

}
