#include "ads/Internal.h"

ADS_NAMESPACE_BEGIN

InternalContentData::InternalContentData() :
	titleWidget(NULL),
	contentWidget(NULL)
{
}

InternalContentData::~InternalContentData()
{
}

ADS_NAMESPACE_END
