#include <iostream>
#include "AnyOldDocument.h"
using namespace std;

AnyOldDocument::AnyOldDocument() :
        documentId(0), documentName("No name yet"), documentType(0)
{
    printf("Invoking 0-parameter constructor for AnyOldDocument\n");
}

AnyOldDocument::AnyOldDocument(int Id, char* name, int docType) :
        documentId(Id), documentName(name), documentType(docType)
{
    printf("Invoking 3-parameter constructor for AnyOldDocument\n");
}

AnyOldDocument::AnyOldDocument(int Id, char* name, int docType, int theNumber) :
        documentId(Id), documentName(name), 
            documentType(docType), associatedNumber(theNumber)
{
    printf("Invoking 4-parameter constructor for AnyOldDocument\n");
}

AnyOldDocument::~AnyOldDocument()
{
    printf("Invoking the destructor for AnyOldDocument\n");
}
