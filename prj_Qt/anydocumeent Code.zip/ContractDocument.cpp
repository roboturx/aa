#include <iostream>
#include "AnyOldDocument.h"
#include "AnyOldDocument1.h"
using namespace std;

