#ifndef ANYOLDDOCUMENT
#define ANYOLDDOCUMENT

class AnyOldDocument {
public:
    AnyOldDocument();
    AnyOldDocument(int Id, char* name, int docType);
    AnyOldDocument(int Id, char* name, int docType, int theNumber);
    virtual ~AnyOldDocument();
    const int GetAssociatedNumber() { return associatedNumber; };
    void SetAssociatedNumber(int newNumber) { associatedNumber = newNumber; };
    virtual void StoreDocument() {};
    virtual void GetDocument() {};
    virtual void DeleteDocument() {};

private:
    int documentId;
    char * documentName;
    int documentType;
    int associatedNumber;
};

enum documentType { INVOICE = 1, CONTRACT = 2,
                    MEMO = 3, PAYSLIP = 4,
                    TAXFORM = 5, SOCIALSEC = 6,
                    ACCOUNTING = 7 };

#endif //ANYOLDDOCUMENT