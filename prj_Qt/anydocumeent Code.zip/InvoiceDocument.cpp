#include <iostream>
#include "AnyOldDocument.h"
using namespace std;

class InvoiceDocument : AnyOldDocument {
public:
    explicit InvoiceDocument(int Id, char* name, int docType, int price);
    virtual ~InvoiceDocument();
    const int getPriceValue();
    void setPriceValue(int number);
    virtual void StoreDocument();
};

InvoiceDocument::InvoiceDocument(int Id, char* name, int docType, int price) 
: AnyOldDocument(Id, name, docType, price)
{
    printf ("Creating an invoice document for: %s\n", name);
}

InvoiceDocument::~InvoiceDocument() { }

const int InvoiceDocument::getPriceValue()
{
    return GetAssociatedNumber();
}

void InvoiceDocument::setPriceValue(int number)
{
    SetAssociatedNumber(number);
}

void InvoiceDocument::StoreDocument()
{
    printf("Now storing invoice in content management system\n");
}

class ContractDocument : AnyOldDocument {
public:
    explicit ContractDocument(int Id, char* name, int docType, int number);
    virtual ~ContractDocument();
    const int getPenaltyClauseValue();
    void setPenaltyClauseValue(int number);
    virtual void StoreDocument();
};

ContractDocument::ContractDocument(int Id, char* name, int docType, int number)
: AnyOldDocument(Id, name, docType, number)
{
    printf ("Creating a contract document for: %s\n", name);
}

ContractDocument::~ContractDocument() { }

const int ContractDocument::getPenaltyClauseValue()
{
    return GetAssociatedNumber();
}

void ContractDocument::setPenaltyClauseValue(int number)
{
    SetAssociatedNumber(number);
}

void ContractDocument::StoreDocument()
{
    printf("Now storing contract to archive\n");
}

class MemoDocument : AnyOldDocument {
public:
    explicit MemoDocument(int Id, char* name, int docType);
    virtual ~MemoDocument();
};

MemoDocument::MemoDocument(int Id, char* name, int docType) 
: AnyOldDocument(Id, name, docType)
{
    printf ("Creating a Memo document for: %s\n", name);
}

MemoDocument::~MemoDocument() { }

int main()
{
    MemoDocument* aMemoDoc = 
        new MemoDocument(222, "Calling All Employees", MEMO);
    InvoiceDocument* anInvoiceDoc = 
        new InvoiceDocument(133, "A Big Customer", INVOICE, 3500);

    printf("Invoice price value %d\n", 
        anInvoiceDoc->getPriceValue());

    anInvoiceDoc->StoreDocument();

    ContractDocument* aContractDoc = 
        new ContractDocument(285, "An Organization", CONTRACT, 1000);

    printf("Contract penalty clause value %d\n", 
        aContractDoc->getPenaltyClauseValue());

    aContractDoc->setPenaltyClauseValue(50000);

    printf("Updated contract penalty clause value %d\n", 
        aContractDoc->getPenaltyClauseValue());

    aContractDoc->StoreDocument();

    // Various workflows
    // Sending documents to recipients
    // Signing documents, archiving, etc.
    // Then finally...    

    delete aMemoDoc;
    delete anInvoiceDoc;
    delete aContractDoc;
    
    return 0;
}