Qt-barcode
==========

A simple application that prints code128 barcodes

### Licence: MIT

