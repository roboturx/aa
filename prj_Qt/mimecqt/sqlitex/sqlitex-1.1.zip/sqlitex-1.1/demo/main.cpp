/**************************************************************************
* Extensible SQLite driver for Qt4
* Copyright (C) 2011-2012 Michał Męciński
*
* This library is free software: you can redistribute it and/or modify
* it under the terms of the GNU Lesser General Public License version 2.1
* as published by the Free Software Foundation.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this library.  If not, see <http://www.gnu.org/licenses/>.
*
* This library is based on the QtSql module of the Qt Toolkit
* Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).
**************************************************************************/

#include <QCoreApplication>
#include <QTextStream>
#include <QSqlDatabase>
#include <QSqlQuery>

static const char* const names[] = {
    "John", "Adam", "ANDREA", "alan", "Michael", "adam", "Samuel"
};

int main( int argc, char** argv )
{
    QCoreApplication application( argc, argv );

    QTextStream error( stderr );
    QTextStream output( stdout );

    QSqlDatabase database = QSqlDatabase::addDatabase( "SQLITEX" );

    database.setDatabaseName( "demo.db" );

    if ( !database.open() ) {
        error << "Opening the database failed." << endl;
        return 1;
    }

    QSqlQuery query( database );

    query.exec( "PRAGMA user_version" );
    query.next();

    int version = query.value( 0 ).toInt();

    if ( version == 0 ) {
        output << "Populating the database" << endl;

        query.exec( "CREATE TABLE demo ( id integer UNIQUE, name text )" );

        query.prepare( "INSERT INTO demo VALUES ( ?, ? )" );

        for ( int i = 0; i < sizeof( names ) / sizeof( const char* ); i++ ) {
            query.addBindValue( i + 1 );
            query.addBindValue( names[ i ] );

            query.exec();
        }

        query.exec( "PRAGMA user_version = 1" );
    }

    output << "Ordering using COLLATE LOCALE:" << endl;

    query.exec( "SELECT id, name FROM demo ORDER BY name COLLATE LOCALE" );

    while ( query.next() )
        output << query.value( 0 ).toInt() << ". " << query.value( 1 ).toString() << endl;


    output << "Comparing using COLLATE NOCASE:" << endl;

    query.exec( "SELECT id, name FROM demo WHERE name COLLATE NOCASE = 'ADAM'" );

    while ( query.next() )
        output << query.value( 0 ).toInt() << ". " << query.value( 1 ).toString() << endl;

    output << "Using the regular expression:" << endl;

    query.exec( "SELECT id, name FROM demo WHERE name REGEXP '.*el'" );

    while ( query.next() )
        output << query.value( 0 ).toInt() << ". " << query.value( 1 ).toString() << endl;

    return 0;
}
