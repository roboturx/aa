/****************************************************************************
* Simple XML-based UI builder for Qt4
* Copyright (C) 2007-2012 Michał Męciński
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*   1. Redistributions of source code must retain the above copyright notice,
*      this list of conditions and the following disclaimer.
*   2. Redistributions in binary form must reproduce the above copyright
*      notice, this list of conditions and the following disclaimer in the
*      documentation and/or other materials provided with the distribution.
*   3. Neither the name of the copyright holder nor the names of the
*      contributors may be used to endorse or promote products derived from
*      this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/

#include "textview.h"

#include <QAction>
#include <QFileDialog>
#include <QMessageBox>
#include <QTextStream>
#include <QApplication>
#include <QClipboard>
#include <QMenu>

#include "iconloader.h"
#include "xmlui/builder.h"

TextView::TextView( QWidget* parent, const QString& path /*= QString()*/ ) : QTextEdit( parent )
{
    QAction* action;

    action = new QAction( IconLoader::icon( "save" ), tr( "Save" ), this );
    setAction( "popupSaveFile", action );

    action = new QAction( IconLoader::icon( "save" ), tr( "&Save" ), this );
    action->setShortcut( QKeySequence::Save );
    connect( action, SIGNAL( triggered() ), this, SLOT( saveFile() ) );
    setAction( "saveFile", action );

    action = new QAction( IconLoader::icon( "save-as" ), tr( "Save &As..." ), this );
    connect( action, SIGNAL( triggered() ), this, SLOT( saveFileAs() ) );
    setAction( "saveFileAs", action );

    action = new QAction( IconLoader::icon( "undo" ), tr( "&Undo" ), this );
    action->setShortcut( QKeySequence::Undo );
    connect( action, SIGNAL( triggered() ), this, SLOT( undo() ) );
    connect( this, SIGNAL( undoAvailable( bool ) ), action, SLOT( setEnabled( bool ) ) );
    setAction( "undo", action );

    action = new QAction( IconLoader::icon( "redo" ), tr( "&Redo" ), this );
    action->setShortcut( QKeySequence::Redo );
    connect( action, SIGNAL( triggered() ), this, SLOT( redo() ) );
    connect( this, SIGNAL( redoAvailable( bool ) ), action, SLOT( setEnabled( bool ) ) );
    setAction( "redo", action );

    action = new QAction( IconLoader::icon( "cut" ), tr( "Cu&t" ), this );
    action->setShortcut( QKeySequence::Cut );
    connect( action, SIGNAL( triggered() ), this, SLOT( cut() ) );
    connect( this, SIGNAL( copyAvailable( bool ) ), action, SLOT( setEnabled( bool ) ) );
    setAction( "cut", action );

    action = new QAction( IconLoader::icon( "copy" ), tr( "&Copy" ), this );
    action->setShortcut( QKeySequence::Copy );
    connect( action, SIGNAL( triggered() ), this, SLOT( copy() ) );
    connect( this, SIGNAL( copyAvailable( bool ) ), action, SLOT( setEnabled( bool ) ) );
    setAction( "copy", action );

    action = new QAction( IconLoader::icon( "paste" ), tr( "&Paste" ), this );
    action->setShortcut( QKeySequence::Paste );
    connect( action, SIGNAL( triggered() ), this, SLOT( paste() ) );
    setAction( "paste", action );

    action = new QAction( tr( "Select &All" ), this );
    action->setShortcut( QKeySequence::SelectAll );
    connect( action, SIGNAL( triggered() ), this, SLOT( selectAll() ) );
    setAction( "selectAll", action );

    setTitle( "sectionClipboard", tr( "Clipboard" ) );
    setTitle( "sectionEdit", tr( "Edit" ) );

    setPopupMenu( "popupSaveFile", "menuSaveFile", "saveFile" );

    loadXmlUiFile( ":/resources/textview.xml" );

    setAcceptRichText( false );
    setContextMenuPolicy( Qt::CustomContextMenu );

    connect( this, SIGNAL( customContextMenuRequested( const QPoint& ) ),
        this, SLOT( contextMenu( const QPoint& ) ) );

    connect( this, SIGNAL( textChanged() ), this, SLOT( updateActions() ) );
    connect( QApplication::clipboard(), SIGNAL( dataChanged() ), this, SLOT( updateClipboard() ) );

    if ( !path.isEmpty() ) {
        if ( readFile( path ) )
            m_path = path;
    }

    updateActions();
    updateClipboard();
}

TextView::~TextView()
{
}

void TextView::updateActions()
{
    action( "undo" )->setEnabled( document()->isUndoAvailable() );
    action( "redo" )->setEnabled( document()->isRedoAvailable() );
    action( "cut" )->setEnabled( textCursor().hasSelection() );
    action( "copy" )->setEnabled( textCursor().hasSelection() );
    action( "selectAll" )->setEnabled( !document()->isEmpty() );
}

void TextView::updateClipboard()
{
    action( "paste" )->setEnabled( !QApplication::clipboard()->text().isEmpty() );
}

void TextView::contextMenu( const QPoint& pos )
{
    QMenu* menu = builder()->contextMenu( "menuText" );
    if ( menu )
        menu->exec( mapToGlobal( pos ) );
}

void TextView::saveFile()
{
    if ( m_path.isEmpty() ) {
        saveFileAs();
    } else {
        writeFile( m_path );
    }
}

void TextView::saveFileAs()
{
    QString path = QFileDialog::getSaveFileName( this, tr( "Save File As" ), m_path );

    if ( !path.isEmpty() ) {
        if ( writeFile( path ) )
            m_path = path;
    }
}

bool TextView::readFile( const QString& path )
{
    QFile file( path );

    if ( file.open( QIODevice::ReadOnly ) ) {
        QTextStream stream( &file );
        setText( stream.readAll() );
        return true;
    } else {
        QMessageBox::warning( this, tr( "Warning" ), tr( "Could not open file" ) );
        return false;
    }
}

bool TextView::writeFile( const QString& path )
{
    QFile file( path );

    if ( file.open( QIODevice::WriteOnly ) ) {
        QTextStream stream( &file );
        stream << toPlainText();
        return true;
    } else {
        QMessageBox::warning( this, tr( "Warning" ), tr( "Could not save file" ) );
        return false;
    }
}
