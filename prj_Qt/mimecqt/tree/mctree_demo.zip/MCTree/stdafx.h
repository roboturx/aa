#pragma once

#define VC_EXTRALEAN

#define _WIN32_WINNT 0x0501

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS

#define _AFX_ALL_WARNINGS

#include <afxwin.h>
#include <afxext.h>
#include <afxcview.h>
#include <afxdisp.h>

#include <afxdtctl.h>
#include <afxcmn.h>

