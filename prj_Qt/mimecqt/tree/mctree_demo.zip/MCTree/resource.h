//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Demo.rc
//
#define IDR_MANIFEST                    1
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_DEMODLG                     103
#define IDR_MAINFRAME                   128
#define IDR_DemoTYPE                    129
#define IDB_IMAGES                      130
#define IDC_COLUMNTREE                  1000
#define IDC_LABEL                       1001
#define ID_VIEW_DIALOGDEMO              32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
