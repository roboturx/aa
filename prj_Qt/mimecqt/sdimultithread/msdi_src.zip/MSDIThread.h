/********************************************************************
* Multithreaded SDI Applications, version 1.5 (October 5, 2002)
* Copyright (C) 2002-2003 Michal Mecinski.
*
* You may freely use and modify this code, but don't remove
* this copyright note.
*
* THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, FOR
* THIS CODE. THE AUTHOR DOES NOT TAKE THE RESPONSIBILITY
* FOR ANY DAMAGE RESULTING FROM THE USE OF IT.
*
* E-mail: mimec@mimec.org
* WWW: http://www.mimec.org
********************************************************************/

#pragma once


#include <afxmt.h>

class CMSDIDocManager;
class CWindowDlg;


class CMSDIThread : public CWinThread
{
	DECLARE_DYNCREATE(CMSDIThread)
protected:
	CMSDIThread();
	virtual ~CMSDIThread();

// Attributes
public:

// Operations
public:
	void SetDocumentTitle(LPCSTR lpszTitle);

// Overrides
	//{{AFX_VIRTUAL(CMSDIThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:
	void FillWindowList();

	void UpdateWindowMenu();

	//{{AFX_MSG(CMSDIThread)
	//}}AFX_MSG
	afx_msg void OnUpdateNotify(WPARAM nCode, LPARAM lParam);
	afx_msg void OnWindowActivate(UINT uCmdID);
	afx_msg void OnWindowSelect();
	DECLARE_MESSAGE_MAP()

public:
	// initial parameters
	CString m_strFileOpen;
	int m_nDocCnt;

	// permission to terminate
	CCriticalSection m_csTerminate;

	// own document manager
	CDocManager* m_pDocManager;

protected:
	// window list dialog box
	CWindowDlg* m_pWndDlg;


public:
	// SHARED DATA
	// only modify and read from other threads within Lock/Unlock

	// document title
	CString m_strTitle;
};

