/********************************************************************
* Multithreaded SDI Applications, version 1.5 (October 5, 2002)
* Copyright (C) 2002-2003 Michal Mecinski.
*
* You may freely use and modify this code, but don't remove
* this copyright note.
*
* THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, FOR
* THIS CODE. THE AUTHOR DOES NOT TAKE THE RESPONSIBILITY
* FOR ANY DAMAGE RESULTING FROM THE USE OF IT.
*
* E-mail: mimec@mimec.org
* WWW: http://www.mimec.org
********************************************************************/

#pragma once

#include "resource.h"

// Command line flags
#define CMD_DDE			0x01
#define CMD_OPEN		0x02
#define CMD_NOSPLASH	0x04
#define CMD_REGSERVER	0x08
#define CMD_UNREGSERVER	0x10


class CMSDIApp : public CWinApp
{
public:
	CMSDIApp();

// Overrides
	//{{AFX_VIRTUAL(CSomeApp)
	public:
	virtual BOOL InitInstance();
	virtual int Run();
	virtual int ExitInstance();
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CMSDIApp)
	afx_msg void OnAppAbout();
	afx_msg void OnAppExit();
	//}}AFX_MSG
protected:
	afx_msg void OnExitThread(WPARAM pThread, LPARAM);
	afx_msg void OnNewInstance(WPARAM nFileOpen, LPARAM);
	DECLARE_MESSAGE_MAP()

protected:
	BOOL ParseCommandLine();
	BOOL ProcessShellCommand();

	BOOL IsAlreadyRunning(LPCSTR lpszName);

	BOOL Register();
	BOOL Unregister();

	void SetRegKey(LPCSTR lpszKey, LPCSTR lpszValue);

	int m_fCommand;
	CString m_strFileOpen;

	CFrameWnd* m_pFrameWnd;
};

//{{AFX_INSERT_LOCATION}}
