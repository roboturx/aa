/********************************************************************
* Multithreaded SDI Applications, version 1.5 (October 5, 2002)
* Copyright (C) 2002-2003 Michal Mecinski.
*
* You may freely use and modify this code, but don't remove
* this copyright note.
*
* THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, FOR
* THIS CODE. THE AUTHOR DOES NOT TAKE THE RESPONSIBILITY
* FOR ANY DAMAGE RESULTING FROM THE USE OF IT.
*
* E-mail: mimec@mimec.org
* WWW: http://www.mimec.org
********************************************************************/

#include "stdafx.h"
#include "MSDI.h"
#include "MSDIThread.h"
#include "MSDIDocManager.h"

#include "MainFrm.h"
#include "SomeDoc.h"
#include "SomeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMSDIThread

IMPLEMENT_DYNCREATE(CMSDIThread, CWinThread)

CMSDIThread::CMSDIThread()
{
	m_pDocManager = NULL;
	m_pWndDlg = NULL;

	m_csTerminate.Lock();
}

CMSDIThread::~CMSDIThread()
{
}


BOOL CMSDIThread::InitInstance()
{
	m_pDocManager = new CDocManager();

	// moved from CMSDIApp::InitInstance

	CSingleDocTemplate* pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CSomeDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CSomeView));

	m_pDocManager->AddDocTemplate(pDocTemplate);

	if (m_strFileOpen.IsEmpty())
	{
		m_pDocManager->OnFileNew();

		if (m_pMainWnd)
		{
			CDocument* pDoc = ((CFrameWnd*)m_pMainWnd)->GetActiveDocument();
			if (pDoc)
			{
				// append document number like in MDI
				CString str;
				str.Format("%s%d", pDoc->GetTitle(), m_nDocCnt);
				pDoc->SetTitle(str);
			}
		}
	}
	else
		m_pDocManager->OpenDocumentFile(m_strFileOpen);

	if (!m_pMainWnd)
		return FALSE;

	m_pMainWnd->BringWindowToTop();

	return TRUE;
}

int CMSDIThread::ExitInstance()
{
	if (m_pMainWnd)
		m_pMainWnd->DestroyWindow();

	delete m_pDocManager;

	AfxGetApp()->PostThreadMessage(MSDIM_EXIT_THREAD, (WPARAM)this, 0);

	// wait for permission to terminate
	m_csTerminate.Lock();

	return CWinThread::ExitInstance();
}


BEGIN_MESSAGE_MAP(CMSDIThread, CWinThread)
	//{{AFX_MSG_MAP(CMSDIThread)
	//}}AFX_MSG_MAP
	ON_THREAD_MESSAGE(MSDIM_UPDATE_NOTIFY, OnUpdateNotify)
	ON_COMMAND_RANGE(MSDI_ID_FIRST, MSDI_ID_LAST, OnWindowActivate)
	ON_COMMAND(MSDI_ID_SELECT, OnWindowSelect)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWindowDlg dialog used for Window Select

class CWindowDlg : public CDialog
{
// Construction
public:
	CWindowDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CWindowDlg)
	enum { IDD = IDD_WINDOW };
	CListBox	m_lbWndList;
	//}}AFX_DATA

	int m_nResult;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWindowDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CWindowDlg)
	virtual void OnOK();
	afx_msg void OnDblclkWindowsList();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CWindowDlg dialog

CWindowDlg::CWindowDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWindowDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWindowDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CWindowDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWindowDlg)
	DDX_Control(pDX, IDC_WINDOW_LIST, m_lbWndList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWindowDlg, CDialog)
	//{{AFX_MSG_MAP(CWindowDlg)
	ON_LBN_DBLCLK(IDC_WINDOW_LIST, OnDblclkWindowsList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWindowDlg message handlers

void CWindowDlg::OnOK() 
{
	m_nResult = m_lbWndList.GetCurSel();
	
	CDialog::OnOK();
}

void CWindowDlg::OnDblclkWindowsList() 
{
	OnOK();	
}


/////////////////////////////////////////////////////////////////////////////
// CMSDIThread message handlers

void CMSDIThread::OnUpdateNotify(WPARAM nCode, LPARAM lParam)
{
	switch (nCode)
	{
	// no need to react on MSDIN_NEW_THREAD because
	// MSDIN_DOC_TITLE is always sent after it
	case MSDIN_EXIT_THREAD:
	case MSDIN_DOC_TITLE:
		// the window dialog will automatically reopen with updated list
		if (m_pWndDlg && m_pWndDlg->m_hWnd && m_pWndDlg->m_lbWndList.m_hWnd)
			FillWindowList();
		UpdateWindowMenu();
		break;
	}
}


void CMSDIThread::SetDocumentTitle(LPCSTR lpszTitle)
{
	CMSDIDocManager* pDocMgr = (CMSDIDocManager*)AfxGetApp()->m_pDocManager;

	pDocMgr->Lock();

	// change the shared data safely
	m_strTitle = lpszTitle;

	pDocMgr->Unlock();

	// send notification message to all threads
	pDocMgr->PostUpdateNotify(MSDIN_DOC_TITLE);
}


void CMSDIThread::OnWindowActivate(UINT uCmdID)
{
	CMSDIDocManager* pDocMgr = (CMSDIDocManager*)AfxGetApp()->m_pDocManager;

	pDocMgr->Lock();

	POSITION pos = pDocMgr->GetFirstThreadPosition();

	int nCnt = uCmdID - MSDI_ID_FIRST;

	while (pos)
	{
		CMSDIThread* pThread = pDocMgr->GetNextThread(pos);

		if (nCnt == 0)
		{
			// restore if it was maximized and switch to foreground
			pThread->GetMainWnd()->ShowWindow(SW_RESTORE);
			pThread->GetMainWnd()->SetForegroundWindow();
			break;
		}

		nCnt--;
	}

	pDocMgr->Unlock();
}


void CMSDIThread::OnWindowSelect()
{
	CWindowDlg dlg;

	m_pWndDlg = &dlg;

	// fill the list after the window is created
	PostThreadMessage(MSDIM_UPDATE_NOTIFY, MSDIN_DOC_TITLE, 0);

	int nRes = dlg.DoModal();

	m_pWndDlg = NULL;

	if (nRes==IDOK && dlg.m_nResult>=0)
		OnWindowActivate(MSDI_ID_FIRST + dlg.m_nResult);
}


void CMSDIThread::FillWindowList()
{
	CMSDIDocManager* pDocMgr = (CMSDIDocManager*)AfxGetApp()->m_pDocManager;

	pDocMgr->Lock();

	POSITION pos = pDocMgr->GetFirstThreadPosition();

	m_pWndDlg->m_lbWndList.ResetContent();

	int nCnt = 0;

	while (pos)
	{
		CMSDIThread* pThread = pDocMgr->GetNextThread(pos);

		m_pWndDlg->m_lbWndList.AddString(pThread->m_strTitle);

		if (pThread == this)
			m_pWndDlg->m_lbWndList.SetCurSel(nCnt);

		nCnt++;
	}

	m_pWndDlg->m_lbWndList.SetFocus();

	pDocMgr->Unlock();
}

void CMSDIThread::UpdateWindowMenu()
{
	if (!m_pMainWnd)
		return;

	CMenu* pMenu = m_pMainWnd->GetMenu();
	int nCnt = pMenu ? pMenu->GetMenuItemCount() : 0;

	if (nCnt < 2)
		return;

	// assume that the Window menu is second from the right
	pMenu = pMenu->GetSubMenu(nCnt-2);

	if (!pMenu)
		return;

	nCnt = pMenu->GetMenuItemCount();
	int nPos = -1;

	// look for previous menu items and delete them
	for (int i=0; i<nCnt; i++)
	{
		UINT nCmd = pMenu->GetMenuItemID(i);
		if (nCmd>=MSDI_ID_FIRST && nCmd<=MSDI_ID_SELECT)
		{
			pMenu->DeleteMenu(i, MF_BYPOSITION);
			nPos = i;	// remember position
			i--; nCnt--;
		}
	}

	if (nPos < 0)	// window list not found
		return;

	CMSDIDocManager* pDocMgr = (CMSDIDocManager*)AfxGetApp()->m_pDocManager;

	// obtain access to the thread list
	pDocMgr->Lock();

	POSITION pos = pDocMgr->GetFirstThreadPosition();
	nCnt = 0;

	while (pos && nCnt<MSDI_MAX_WINDOWS)
	{
		CMSDIThread* pThread = pDocMgr->GetNextThread(pos);
		
		// title can be accessed safely now
		CString strItem;
		strItem.Format("&%d %s", nCnt+1, pThread->m_strTitle);

		pMenu->InsertMenu(nPos+nCnt, MF_BYPOSITION, MSDI_ID_FIRST+nCnt, strItem);
		
		if (pThread == this)	// check if it's the current window
			pMenu->CheckMenuItem(nPos+nCnt, MF_BYPOSITION | MF_CHECKED);

		nCnt++;
	}

	// there are more windows than displayed in the menu
	if (pos)
		pMenu->InsertMenu(nPos+nCnt, MF_BYPOSITION, MSDI_ID_SELECT, "&More windows...");

	pDocMgr->Unlock();
}
