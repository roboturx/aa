/********************************************************************
* Multithreaded SDI Applications, version 1.5 (October 5, 2002)
* Copyright (C) 2002-2003 Michal Mecinski.
*
* You may freely use and modify this code, but don't remove
* this copyright note.
*
* THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, FOR
* THIS CODE. THE AUTHOR DOES NOT TAKE THE RESPONSIBILITY
* FOR ANY DAMAGE RESULTING FROM THE USE OF IT.
*
* E-mail: mimec@mimec.org
* WWW: http://www.mimec.org
********************************************************************/

#pragma once


// thread messages
#define MSDIM_EXIT_THREAD	(WM_USER + 1)
#define MSDIM_NEW_INSTANCE	(WM_USER + 2)
#define MSDIM_UPDATE_NOTIFY	(WM_USER + 3)

// update nofitication codes
#define MSDIN_NEW_THREAD	1
#define MSDIN_EXIT_THREAD	2
#define MSDIN_DOC_TITLE		3

// maximum number of windows in menu
#define MSDI_MAX_WINDOWS	9


#define MSDI_ID_FIRST	AFX_IDM_FIRST_MDICHILD
#define MSDI_ID_LAST	(AFX_IDM_FIRST_MDICHILD+MSDI_MAX_WINDOWS-1)
#define MSDI_ID_SELECT	(AFX_IDM_FIRST_MDICHILD+MSDI_MAX_WINDOWS)

#include <afxtempl.h>
#include <afxmt.h>

class CMSDIThread;


class CMSDIDocManager : public CDocManager
{
public:
	CMSDIDocManager();
	virtual ~CMSDIDocManager();

// Overrides
public:
	virtual void OnFileNew();
	virtual void OnFileOpen();
	virtual CDocument* OpenDocumentFile(LPCTSTR lpszFileName);
	virtual BOOL DoPromptFileName(CString& fileName, UINT nIDSTitle,
			DWORD lFlags, BOOL bOpenFileDialog, CDocTemplate* pTemplate);
	virtual BOOL OnDDECommand(LPTSTR lpszCommand);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Implementation
protected:
	CTypedPtrList<CPtrList, CMSDIThread*> m_ThreadList;

	CCriticalSection m_CriticalSection;

	int m_nDocCnt;

protected:
	void OnExitThread(CMSDIThread* pThread);
	void KillAllThreads();

	friend class CMSDIApp;


// Public functions
public:
	// safely close the application
	void CloseAllFrames();

	// check if doc already open in other thread and if so show it
	BOOL ShowIfAlreadyOpen(LPCTSTR lpszFileName);

	// post message to all threads
	void PostMessageToAll(UINT message, WPARAM wParam=0, LPARAM lParam=0);
	
	// post update notify message
	void PostUpdateNotify(UINT nCode, LPARAM lParam=0)
	{
		PostMessageToAll(MSDIM_UPDATE_NOTIFY, nCode, lParam);
	}


	// access to the thread list and thread public data
	void Lock() { m_CriticalSection.Lock(); }
	void Unlock() { m_CriticalSection.Unlock(); }

	// use the following only between Lock() and Unlock()
	BOOL IsThreadListEmpty() { return m_ThreadList.IsEmpty(); }
	POSITION GetFirstThreadPosition() { return m_ThreadList.GetHeadPosition(); }
	CMSDIThread* GetNextThread(POSITION& pos) { return m_ThreadList.GetNext(pos); }
};

