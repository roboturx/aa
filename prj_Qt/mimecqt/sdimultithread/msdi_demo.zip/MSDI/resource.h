//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MSDI.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MSDITYPE                    129
#define IDD_WINDOW                      131
#define IDC_WINDOW_LIST                 1001
#define ID_WINDOW_YYY                   32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
