// SomeDoc.cpp : implementation of the CSomeDoc class
//

#include "stdafx.h"
#include "MSDI.h"

#include "SomeDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSomeDoc

IMPLEMENT_DYNCREATE(CSomeDoc, CDocument)

BEGIN_MESSAGE_MAP(CSomeDoc, CDocument)
	//{{AFX_MSG_MAP(CSomeDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSomeDoc construction/destruction

CSomeDoc::CSomeDoc()
{
}

CSomeDoc::~CSomeDoc()
{
}

BOOL CSomeDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	((CEditView*)m_viewList.GetHead())->SetWindowText(NULL);

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSomeDoc serialization

void CSomeDoc::Serialize(CArchive& ar)
{
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CSomeDoc diagnostics

#ifdef _DEBUG
void CSomeDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSomeDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSomeDoc commands
