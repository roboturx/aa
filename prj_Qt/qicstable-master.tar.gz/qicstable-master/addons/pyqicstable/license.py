# Configure the build process for the commercial version.

LicenseType = "commercial"
LicenseName = "PyQicsTable Commercial License"
LicenseFile = "pyqicstable-commercial.sip"
