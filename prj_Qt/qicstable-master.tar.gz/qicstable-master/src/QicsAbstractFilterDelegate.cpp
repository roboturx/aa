/*********************************************************************
**
** Copyright (C) 2002-2014 Integrated Computer Solutions, Inc.
** All rights reserved.
**
** This file is part of the QicsTable software.
**
** See the top level README file for license terms under which this
** software can be used, distributed, or modified.
**
**********************************************************************/

#include "QicsAbstractFilterDelegate.h"


QicsAbstractFilterDelegate::QicsAbstractFilterDelegate(QObject *parent)
    : QObject(parent)
{
}

QicsAbstractFilterDelegate::~QicsAbstractFilterDelegate()
{
}


