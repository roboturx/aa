<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="en">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.cpp" line="73"/>
        <source>Set a root directory then press Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="81"/>
        <source>Root Directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="96"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="97"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="99"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="164"/>
        <source>Reading files...</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="203"/>
        <source>Read %Ln file(s)</source>
        <translation>
            <numerusform>Read one file</numerusform>
            <numerusform>Read %Ln files</numerusform>
        </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="150"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="151"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>Read the names and sizes of %Ln file(s) so far...</source>
        <translation type="obsolete">
            <numerusform>Read the name and size of one file so far...</numerusform>
            <numerusform>Read the names and sizes of %Ln files so far...</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="mainwindow.cpp" line="223"/>
        <source>Found %Ln duplicate file(s)</source>
        <translation>
            <numerusform>Found one duplicate file</numerusform>
            <numerusform>Found %Ln duplicate files</numerusform>
        </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="309"/>
        <source>Canceled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message numerus="yes">
        <source>Read the names and sizes of %Ln file(s)</source>
        <translation type="obsolete">
            <numerusform>Read the names and sizes of one file</numerusform>
            <numerusform>Read the names and sizes of %Ln files</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>%Ln item(s) to process</source>
        <translation type="obsolete">
            <numerusform>One item to process</numerusform>
            <numerusform>%Ln items to process</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>; %Ln result(s) to show</source>
        <translation type="obsolete">
            <numerusform>; one result to show</numerusform>
            <numerusform>; %Ln results to show</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../aqp/aqp.cpp" line="147"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aqp/aqp.cpp" line="148"/>
        <source>Do &amp;Not Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>Read the names and sizes of %Ln file(s) so far...</source>
        <translation type="obsolete">
            <numerusform>Read the name and size of one file so far...</numerusform>
            <numerusform>Read the names and sizes of %Ln files so far...</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.cpp" line="23"/>
        <source>Find Duplicates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
