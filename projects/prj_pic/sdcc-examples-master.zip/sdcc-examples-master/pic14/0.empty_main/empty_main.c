// Copyright (C) 2014 Diego Herranz

#include <pic14regs.h>

void main(void)
{
}
