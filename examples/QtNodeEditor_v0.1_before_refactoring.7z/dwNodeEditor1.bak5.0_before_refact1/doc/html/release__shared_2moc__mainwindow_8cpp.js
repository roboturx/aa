var release__shared_2moc__mainwindow_8cpp =
[
    [ "qt_meta_data_MainWindow", "release__shared_2moc__mainwindow_8cpp.html#a1dd2e133e39a5ebf8d05650bb3b3741a", null ],
    [ "qt_meta_data_MyFasterGraphicView", "release__shared_2moc__mainwindow_8cpp.html#a716336b43ebb82f5c8c64ac7d6b75248", null ],
    [ "qt_meta_stringdata_MainWindow", "release__shared_2moc__mainwindow_8cpp.html#a82fbcdc12b3520fb6616a53cc8e70274", null ],
    [ "qt_meta_stringdata_MyFasterGraphicView", "release__shared_2moc__mainwindow_8cpp.html#abd0ba39deb3cb7c04fd070fce98d5108", null ]
];