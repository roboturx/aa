var class_my_faster_graphic_view =
[
    [ "MyFasterGraphicView", "class_my_faster_graphic_view.html#a00d9e0848b43a3110dfab3b8cf291978", null ],
    [ "paintEvent", "class_my_faster_graphic_view.html#a753dd2e1291e9adf3eb8f966151e6fc4", null ]
];