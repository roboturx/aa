var annotated =
[
    [ "DiagramScene", "class_diagram_scene.html", "class_diagram_scene" ],
    [ "ExampleBaseNode", "class_example_base_node.html", "class_example_base_node" ],
    [ "ExampleDiagramScene", "class_example_diagram_scene.html", "class_example_diagram_scene" ],
    [ "ExampleNode1", "class_example_node1.html", "class_example_node1" ],
    [ "ExampleNode2", "class_example_node2.html", "class_example_node2" ],
    [ "ExampleNode5", "class_example_node5.html", "class_example_node5" ],
    [ "ExampleNode6", "class_example_node6.html", "class_example_node6" ],
    [ "ExampleNode7", "class_example_node7.html", "class_example_node7" ],
    [ "ExampleNode8", "class_example_node8.html", "class_example_node8" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "MyFasterGraphicView", "class_my_faster_graphic_view.html", "class_my_faster_graphic_view" ],
    [ "NodeConnection", "class_node_connection.html", "class_node_connection" ],
    [ "NodeConnector", "class_node_connector.html", "class_node_connector" ],
    [ "NodeConnectorBase", "class_node_connector_base.html", "class_node_connector_base" ],
    [ "NodeItem", "class_node_item.html", "class_node_item" ],
    [ "NodeItemBase", "class_node_item_base.html", "class_node_item_base" ],
    [ "Ui::StyleSheetEditor", "class_ui_1_1_style_sheet_editor.html", null ],
    [ "StyleSheetEditor", "class_style_sheet_editor.html", "class_style_sheet_editor" ],
    [ "Ui_StyleSheetEditor", "class_ui___style_sheet_editor.html", "class_ui___style_sheet_editor" ],
    [ "WindowFlagsEditor", "class_window_flags_editor.html", "class_window_flags_editor" ]
];