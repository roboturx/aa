var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a34c4b4207b46d11a4100c9b19f0e81bb", null ],
    [ "setNodeItemsStyle", "class_main_window.html#a665e74dd4fe5e73b17e181bd5033b915", null ],
    [ "setNodeItemsStylesheet", "class_main_window.html#a7729bfa47751d05dd8790a256e09f6ad", null ],
    [ "setNoteItemsWindowFlags", "class_main_window.html#a6a3155a89b12935b29f2969c589e6a1c", null ]
];