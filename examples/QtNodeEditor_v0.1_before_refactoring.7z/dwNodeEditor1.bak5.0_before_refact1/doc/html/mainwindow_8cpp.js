var mainwindow_8cpp =
[
    [ "InsertNode2Button", "mainwindow_8cpp.html#aa0ad66b110786aae434820b1edb0193b", null ],
    [ "InsertNodeButton", "mainwindow_8cpp.html#ae9c85a92dfd8da962ecaf7b2e27e4a2d", null ],
    [ "InsertTextButton", "mainwindow_8cpp.html#aa87c97d6124c23c418e57c1666cd8a0f", null ]
];