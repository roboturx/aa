var class_window_flags_editor =
[
    [ "WindowFlagsEditor", "class_window_flags_editor.html#aa2792f7da6c8e31f15e66e1086f99020", null ],
    [ "newWindowFlags", "class_window_flags_editor.html#af91db3eb2cb18f074440feaca932bac2", null ]
];