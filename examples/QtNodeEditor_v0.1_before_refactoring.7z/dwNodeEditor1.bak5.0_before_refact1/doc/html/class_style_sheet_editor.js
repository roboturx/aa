var class_style_sheet_editor =
[
    [ "StyleSheetEditor", "class_style_sheet_editor.html#a9ba64586c76dd8f8c78ecb496d1bead4", null ],
    [ "newStyle", "class_style_sheet_editor.html#aeac530fbc1276b54fe2bc97123588027", null ],
    [ "newStylesheet", "class_style_sheet_editor.html#aae289bfacd7b3ed9e96529df044ad5a4", null ]
];