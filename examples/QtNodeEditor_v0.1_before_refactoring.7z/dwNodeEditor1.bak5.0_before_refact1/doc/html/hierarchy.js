var hierarchy =
[
    [ "DiagramScene", "class_diagram_scene.html", [
      [ "ExampleDiagramScene", "class_example_diagram_scene.html", null ]
    ] ],
    [ "MainWindow", "class_main_window.html", null ],
    [ "MyFasterGraphicView", "class_my_faster_graphic_view.html", null ],
    [ "NodeConnection", "class_node_connection.html", null ],
    [ "NodeConnector", "class_node_connector.html", null ],
    [ "NodeConnectorBase", "class_node_connector_base.html", null ],
    [ "NodeItem", "class_node_item.html", [
      [ "ExampleBaseNode", "class_example_base_node.html", [
        [ "ExampleNode1", "class_example_node1.html", null ],
        [ "ExampleNode2", "class_example_node2.html", null ],
        [ "ExampleNode5", "class_example_node5.html", null ],
        [ "ExampleNode6", "class_example_node6.html", null ],
        [ "ExampleNode7", "class_example_node7.html", null ],
        [ "ExampleNode8", "class_example_node8.html", null ]
      ] ]
    ] ],
    [ "NodeItemBase", "class_node_item_base.html", null ],
    [ "StyleSheetEditor", "class_style_sheet_editor.html", null ],
    [ "Ui_StyleSheetEditor", "class_ui___style_sheet_editor.html", [
      [ "Ui::StyleSheetEditor", "class_ui_1_1_style_sheet_editor.html", null ],
      [ "Ui::StyleSheetEditor", "class_ui_1_1_style_sheet_editor.html", null ]
    ] ],
    [ "WindowFlagsEditor", "class_window_flags_editor.html", null ]
];