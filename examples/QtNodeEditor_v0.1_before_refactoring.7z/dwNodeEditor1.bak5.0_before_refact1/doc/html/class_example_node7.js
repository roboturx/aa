var class_example_node7 =
[
    [ "ExampleNode7", "class_example_node7.html#add929a53665eb789ef8d2f0eff072514", null ],
    [ "getId", "class_example_node7.html#afaac6f88692fc56b96a8b806b8a8ec6a", null ]
];