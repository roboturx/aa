var class_ui___style_sheet_editor =
[
    [ "retranslateUi", "class_ui___style_sheet_editor.html#aec84e7d4525435e61ca78ac579d9ed9b", null ],
    [ "retranslateUi", "class_ui___style_sheet_editor.html#aec84e7d4525435e61ca78ac579d9ed9b", null ],
    [ "setupUi", "class_ui___style_sheet_editor.html#a4b44bb408a5bbabb9e2d4665638423d8", null ],
    [ "setupUi", "class_ui___style_sheet_editor.html#a4b44bb408a5bbabb9e2d4665638423d8", null ],
    [ "applyButton", "class_ui___style_sheet_editor.html#a9234e5fd83e14008248c3273138eba9c", null ],
    [ "gridLayout", "class_ui___style_sheet_editor.html#a5af4c6e0f7f60fb1226e450444b7e204", null ],
    [ "hboxLayout", "class_ui___style_sheet_editor.html#a1cb757afb99369517b955bcdb04dd7f4", null ],
    [ "label_7", "class_ui___style_sheet_editor.html#a3740d999d6c94accb8342272a922bd6e", null ],
    [ "label_8", "class_ui___style_sheet_editor.html#a549c9a695bc13a0c3a36048e6989e9f2", null ],
    [ "spacerItem", "class_ui___style_sheet_editor.html#a126d0546d2d22bc206e30ffe453f5089", null ],
    [ "spacerItem1", "class_ui___style_sheet_editor.html#a10f6bcb57aa0fb2af6b6e64f6c1a1536", null ],
    [ "spacerItem2", "class_ui___style_sheet_editor.html#a1b57d2a0a348512398adb8261539a2b4", null ],
    [ "spacerItem3", "class_ui___style_sheet_editor.html#a32579732b7c8f14b932c11629f2eb4ec", null ],
    [ "styleCombo", "class_ui___style_sheet_editor.html#afef60a9ec983a12904b99602b61009ff", null ],
    [ "styleSheetCombo", "class_ui___style_sheet_editor.html#a0d53e4c2567f1a870c15ff172007453b", null ],
    [ "styleTextEdit", "class_ui___style_sheet_editor.html#a9c839ed4e861a28e91e78bd4d00b546d", null ]
];